import http from 'http';
import url, {URLSearchParams} from 'url';

const host = 'localhost';
const porta = 4000;

function responderRequisicao(requisicao, resposta){
if(requisicao.method === "GET"){
     const dados = new URLSearchParams(url.parse(requisicao.url).query);
     const tabuada = parseInt(dados.get('tabuada'));
     const sequencia = parseInt(dados.get('sequencia')) || 10 ;
    resposta.setHeader('Content-Type','text/html');
    resposta.write('<html>');
    resposta.write('<head>');
    resposta.write('</head>');
    resposta.write('<body>');
    if (!isNaN(tabuada)) {
        resposta.write(`<h1>Tabuada do ${tabuada}</h1>`);
        for (let i = 0; i <= sequencia; i++) {
            resposta.write(`<p>${tabuada} x ${i} = ${tabuada * i}</p>`);
        }
    } else {
        resposta.write('<p>Por favor, forneça um número válido para a tabuada.</p>');
    }
    resposta.write('</body>');
    resposta.write('</html>');
    resposta.end();

}
    
}

const servidor = http.createServer(responderRequisicao);
servidor.listen(porta, host, () => {
    console.log('Servidor escutando em http://'+host+':'+porta);
});
